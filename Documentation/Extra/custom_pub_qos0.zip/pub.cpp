#include "pub.h"
#include "pub_internals.h"


uint64_t g_bytes_received = 0;
uint64_t g_bytes_sent = 0;
uint64_t g_pub_bytes_received = 0;
uint64_t g_pub_bytes_sent = 0;
unsigned long g_msgs_received = 0;
unsigned long g_msgs_sent = 0;
unsigned long g_pub_msgs_received = 0;
unsigned long g_pub_msgs_sent = 0;
unsigned long g_msgs_dropped = 0;
int g_clients_expired = 0;
unsigned int g_socket_connections = 0;
unsigned int g_connection_count = 0;

// int add(int a, int b)
// {
//     return a+b;
// }

// void server()
// {

//     struct sockaddr_in address;
//     int addrlen=sizeof(address);
//     char buffer[LEN];
//     char *hello="Hello from the other side";

//     int sock_desc=socket(AF_INET,SOCK_STREAM,0);

//     address.sin_family=AF_INET;
//     address.sin_addr.s_addr=INADDR_ANY;
//     address.sin_port=htons(1883);

//     if(bind(sock_desc, (struct sockaddr *)&address, sizeof(address))<0)
//         printf("bind Failed.\n");

//     listen(sock_desc, 4);
//         // printf("bind Failed.\n");

//     int sock1=accept(sock_desc, (struct sockaddr *)&address,(socklen_t *)&addrlen);


//     send(sock1, hello, strlen(hello),0);
// }


///////////////////////////////mosquitto.c///////////////////////////////////

void mosquitto_destroy(struct mosquitto *mosq)
{       
        if(!mosq) return;
        
        mosquitto__destroy(mosq);
        free(mosq);
}

void mosquitto__destroy(struct mosquitto *mosq)
{
	struct mosquitto__packet *packet;
	if(!mosq) return;

// #ifdef WITH_THREADING
// #  ifdef HAVE_PTHREAD_CANCEL
	if(mosq->threaded == mosq_ts_self && !pthread_equal(mosq->thread_id, pthread_self())){
		pthread_cancel(mosq->thread_id);
		pthread_join(mosq->thread_id, NULL);
		mosq->threaded = mosq_ts_none;
	}
// #  endif

	if(mosq->id){
		/* If mosq->id is not NULL then the client has already been initialised
		 * and so the mutexes need destroying. If mosq->id is NULL, the mutexes
		 * haven't been initialised. */
		pthread_mutex_destroy(&mosq->callback_mutex);
		pthread_mutex_destroy(&mosq->log_callback_mutex);
		pthread_mutex_destroy(&mosq->state_mutex);
		pthread_mutex_destroy(&mosq->out_packet_mutex);
		pthread_mutex_destroy(&mosq->current_out_packet_mutex);
		pthread_mutex_destroy(&mosq->msgtime_mutex);
		pthread_mutex_destroy(&mosq->msgs_in.mutex);
		pthread_mutex_destroy(&mosq->msgs_out.mutex);
		pthread_mutex_destroy(&mosq->mid_mutex);
	}
// #endif
	if(mosq->sock != INVALID_SOCKET){
		net__socket_close(mosq);
	}
	message__cleanup_all(mosq);
	// will__clear(mosq);
// #ifdef WITH_TLS
// 	if(mosq->ssl){
// 		SSL_free(mosq->ssl);
// 	}
// 	if(mosq->ssl_ctx){
// 		SSL_CTX_free(mosq->ssl_ctx);
// 	}
// 	free(mosq->tls_cafile);
// 	free(mosq->tls_capath);
// 	free(mosq->tls_certfile);
// 	free(mosq->tls_keyfile);
// 	if(mosq->tls_pw_callback) mosq->tls_pw_callback = NULL;
// 	free(mosq->tls_version);
// 	free(mosq->tls_ciphers);
// 	free(mosq->tls_psk);
// 	free(mosq->tls_psk_identity);
// 	free(mosq->tls_alpn);
// #endif

	free(mosq->address);
	mosq->address = NULL;

	free(mosq->id);
	mosq->id = NULL;

	free(mosq->username);
	mosq->username = NULL;

	free(mosq->password);
	mosq->password = NULL;

	free(mosq->host);
	mosq->host = NULL;

	free(mosq->bind_address);
	mosq->bind_address = NULL;

	/* Out packet cleanup */
	if(mosq->out_packet && !mosq->current_out_packet){
		mosq->current_out_packet = mosq->out_packet;
		mosq->out_packet = mosq->out_packet->next;
	}
	while(mosq->current_out_packet){
		packet = mosq->current_out_packet;
		/* Free data and reset values */
		mosq->current_out_packet = mosq->out_packet;
		if(mosq->out_packet){
			mosq->out_packet = mosq->out_packet->next;
		}

		packet__cleanup(packet);
		free(packet);
	}

	packet__cleanup(&mosq->in_packet);
	if(mosq->sockpairR != INVALID_SOCKET){
		close(mosq->sockpairR);
		mosq->sockpairR = INVALID_SOCKET;
	}
	if(mosq->sockpairW != INVALID_SOCKET){
		close(mosq->sockpairW);
		mosq->sockpairW = INVALID_SOCKET;
	}
}

struct mosquitto *mosquitto_new(const char *id, bool clean_start, void *userdata)
{
	struct mosquitto *mosq = NULL;
	int rc;

	if(clean_start == false && id == NULL){
		errno = EINVAL;
		return NULL;
	}

// #ifndef WIN32
// 	signal(SIGPIPE, SIG_IGN);
// #endif

	mosq = (struct mosquitto *)calloc(1, sizeof(struct mosquitto));
	if(mosq){
		mosq->sock = INVALID_SOCKET;
		mosq->sockpairR = INVALID_SOCKET;
		mosq->sockpairW = INVALID_SOCKET;

		rc = mosquitto_reinitialise(mosq, id, clean_start, userdata);
		if(rc){
			mosquitto_destroy(mosq);
			if(rc == MOSQ_ERR_INVAL){
				errno = EINVAL;
			}else if(rc == MOSQ_ERR_NOMEM){
				errno = ENOMEM;
			}
			return NULL;
		}
	}else{
		errno = ENOMEM;
	}
	return mosq;
}

int mosquitto_reinitialise(struct mosquitto *mosq, const char *id, bool clean_start, void *userdata)
{
	if(!mosq) return MOSQ_ERR_INVAL;

	if(clean_start == false && id == NULL){
		return MOSQ_ERR_INVAL;
	}

	mosquitto__destroy(mosq);
	memset(mosq, 0, sizeof(struct mosquitto));

	if(userdata){
		mosq->userdata = userdata;
	}else{
		mosq->userdata = mosq;
	}
	mosq->protocol = mosq_p_mqtt311;
	mosq->sock = INVALID_SOCKET;
	mosq->sockpairR = INVALID_SOCKET;
	mosq->sockpairW = INVALID_SOCKET;
	mosq->keepalive = 60;
	mosq->clean_start = clean_start;
	if(id){
		if(STREMPTY(id)){
			return MOSQ_ERR_INVAL;
		}
		if(mosquitto_validate_utf8(id, strlen(id))){
			return MOSQ_ERR_MALFORMED_UTF8;
		}
		mosq->id = strdup(id);
	}
	mosq->in_packet.payload = NULL;
	packet__cleanup(&mosq->in_packet);
	mosq->out_packet = NULL;
	mosq->current_out_packet = NULL;
	mosq->last_msg_in = mosquitto_time();
	mosq->next_msg_out = mosquitto_time() + mosq->keepalive;
	mosq->ping_t = 0;
	mosq->last_mid = 0;
	mosq->state = mosq_cs_new;
	mosq->maximum_qos = 2;
	mosq->msgs_in.inflight_maximum = 20;
	mosq->msgs_out.inflight_maximum = 20;
	mosq->msgs_in.inflight_quota = 20;
	mosq->msgs_out.inflight_quota = 20;
	mosq->will = NULL;
	mosq->on_connect = NULL;
	mosq->on_publish = NULL;
	mosq->on_message = NULL;
	mosq->on_subscribe = NULL;
	mosq->on_unsubscribe = NULL;
	mosq->host = NULL;
	mosq->port = 1883;
	mosq->in_callback = false;
	mosq->reconnect_delay = 1;
	mosq->reconnect_delay_max = 1;
	mosq->reconnect_exponential_backoff = false;
	mosq->threaded = mosq_ts_none;
// #ifdef WITH_TLS
// 	mosq->ssl = NULL;
// 	mosq->ssl_ctx = NULL;
// 	mosq->tls_cert_reqs = SSL_VERIFY_PEER;
// 	mosq->tls_insecure = false;
// 	mosq->want_write = false;
// 	mosq->tls_ocsp_required = false;
// // #endif
// // #ifdef WITH_THREADING
	pthread_mutex_init(&mosq->callback_mutex, NULL);
	pthread_mutex_init(&mosq->log_callback_mutex, NULL);
	pthread_mutex_init(&mosq->state_mutex, NULL);
	pthread_mutex_init(&mosq->out_packet_mutex, NULL);
	pthread_mutex_init(&mosq->current_out_packet_mutex, NULL);
	pthread_mutex_init(&mosq->msgtime_mutex, NULL);
	pthread_mutex_init(&mosq->msgs_in.mutex, NULL);
	pthread_mutex_init(&mosq->msgs_out.mutex, NULL);
	pthread_mutex_init(&mosq->mid_mutex, NULL);
	mosq->thread_id = pthread_self();
// #endif

	return MOSQ_ERR_SUCCESS;
}

// int mosquitto_reinitialise(struct mosquitto *mosq, const char *id, bool clean_start, void *userdata)
// {
// 	if(!mosq) return MOSQ_ERR_INVAL;

// 	if(clean_start == false && id == NULL){
// 		return MOSQ_ERR_INVAL;
// 	}

// 	mosquitto__destroy(mosq);
// 	memset(mosq, 0, sizeof(struct mosquitto));

// 	if(userdata){
// 		mosq->userdata = userdata;
// 	}else{
// 		mosq->userdata = mosq;
// 	}
// 	mosq->protocol = mosq_p_mqtt311;
// 	mosq->sock = INVALID_SOCKET;
// 	mosq->sockpairR = INVALID_SOCKET;
// 	mosq->sockpairW = INVALID_SOCKET;
// 	mosq->keepalive = 60;
// 	mosq->clean_start = clean_start;
// 	if(id){
// 		if(STREMPTY(id)){
// 			return MOSQ_ERR_INVAL;
// 		}
// 		if(mosquitto_validate_utf8(id, strlen(id))){
// 			return MOSQ_ERR_MALFORMED_UTF8;
// 		}
// 		mosq->id = strdup(id);
// 	}
// 	mosq->in_packet.payload = NULL;
// 	packet__cleanup(&mosq->in_packet);
// 	mosq->out_packet = NULL;
// 	mosq->current_out_packet = NULL;
// 	mosq->last_msg_in = mosquitto_time();
// 	mosq->next_msg_out = mosquitto_time() + mosq->keepalive;
// 	mosq->ping_t = 0;
// 	mosq->last_mid = 0;
// 	mosq->state = mosq_cs_new;
// 	mosq->maximum_qos = 2;
// 	mosq->msgs_in.inflight_maximum = 20;
// 	mosq->msgs_out.inflight_maximum = 20;
// 	mosq->msgs_in.inflight_quota = 20;
// 	mosq->msgs_out.inflight_quota = 20;
// 	mosq->will = NULL;
// 	mosq->on_connect = NULL;
// 	mosq->on_publish = NULL;
// 	mosq->on_message = NULL;
// 	mosq->on_subscribe = NULL;
// 	mosq->on_unsubscribe = NULL;
// 	mosq->host = NULL;
// 	mosq->port = 1883;
// 	mosq->in_callback = false;
// 	mosq->reconnect_delay = 1;
// 	mosq->reconnect_delay_max = 1;
// 	mosq->reconnect_exponential_backoff = false;
// 	mosq->threaded = mosq_ts_none;

// 	return MOSQ_ERR_SUCCESS;
// }


///////////////////////////////connect.c///////////////////////////////////

void do_client_disconnect(struct mosquitto *mosq, int reason_code, const mosquitto_property *properties)              
{                               
        mosquitto__set_state(mosq, mosq_cs_disconnected);
        net__socket_close(mosq);

        /* Free data and reset values */
        pthread_mutex_lock(&mosq->out_packet_mutex);
        mosq->current_out_packet = mosq->out_packet;
        if(mosq->out_packet){
                mosq->out_packet = mosq->out_packet->next;
                if(!mosq->out_packet){
                        mosq->out_packet_last = NULL;
                }       
        }
        pthread_mutex_unlock(&mosq->out_packet_mutex);

        pthread_mutex_lock(&mosq->msgtime_mutex);
        mosq->next_msg_out = mosquitto_time() + mosq->keepalive;
        pthread_mutex_unlock(&mosq->msgtime_mutex);
                
        pthread_mutex_lock(&mosq->callback_mutex);
        if(mosq->on_disconnect){
                mosq->in_callback = true;
                mosq->on_disconnect(mosq, mosq->userdata, reason_code);
                mosq->in_callback = false;
        }       
        if(mosq->on_disconnect_v5){
                mosq->in_callback = true;
                mosq->on_disconnect_v5(mosq, mosq->userdata, reason_code, properties);
                mosq->in_callback = false;
        }
        pthread_mutex_unlock(&mosq->callback_mutex);
        pthread_mutex_unlock(&mosq->current_out_packet_mutex);
}

static int mosquitto__connect_init(struct mosquitto *mosq, const char *host, int port, int keepalive, const char *bind_address)
{
	int i;
	int rc;

	if(!mosq) return MOSQ_ERR_INVAL;
	if(!host || port <= 0) return MOSQ_ERR_INVAL;
	if(keepalive < 5) return MOSQ_ERR_INVAL;

	if(mosq->id == NULL && (mosq->protocol == mosq_p_mqtt31 || mosq->protocol == mosq_p_mqtt311)){
		mosq->id = (char *)calloc(24, sizeof(char));
		if(!mosq->id){
			return MOSQ_ERR_NOMEM;
		}
		mosq->id[0] = 'm';
		mosq->id[1] = 'o';
		mosq->id[2] = 's';
		mosq->id[3] = 'q';
		mosq->id[4] = '-';

		rc = util__random_bytes(&mosq->id[5], 18);
		if(rc) return rc;

		for(i=5; i<23; i++){
			mosq->id[i] = alphanum[(mosq->id[i]&0x7F)%(sizeof(alphanum)-1)];
		}
	}

	free(mosq->host);
	mosq->host = strdup(host);
	if(!mosq->host) return MOSQ_ERR_NOMEM;
	mosq->port = port;

	free(mosq->bind_address);
	// if(bind_address){
	// 	mosq->bind_address = mosquitto__strdup(bind_address);
	// 	if(!mosq->bind_address) return MOSQ_ERR_NOMEM;
	// }

	mosq->keepalive = keepalive;
	mosq->msgs_in.inflight_quota = mosq->msgs_in.inflight_maximum;
	mosq->msgs_out.inflight_quota = mosq->msgs_out.inflight_maximum;

	if(mosq->sockpairR != INVALID_SOCKET){
		close(mosq->sockpairR);
		mosq->sockpairR = INVALID_SOCKET;
	}
	if(mosq->sockpairW != INVALID_SOCKET){
		close(mosq->sockpairW);
		mosq->sockpairW = INVALID_SOCKET;
	}

	if(net__socketpair(&mosq->sockpairR, &mosq->sockpairW)){
		log__printf(mosq, MOSQ_LOG_WARNING,
				"Warning: Unable to open socket pair, outgoing publish commands may be delayed.");
	}

	return MOSQ_ERR_SUCCESS;
}

int mosquitto_connect(struct mosquitto *mosq, const char *host, int port, int keepalive)
{
	return mosquitto_connect_bind(mosq, host, port, keepalive, NULL);
}


int mosquitto_connect_bind(struct mosquitto *mosq, const char *host, int port, int keepalive, const char *bind_address)
{
	return mosquitto_connect_bind_v5(mosq, host, port, keepalive, bind_address, NULL);
}

int mosquitto_connect_bind_v5(struct mosquitto *mosq, const char *host, int port, int keepalive, const char *bind_address, const mosquitto_property *properties)
{
	int rc;

	// if(properties){
	// 	rc = mosquitto_property_check_all(CMD_CONNECT, properties);
	// 	if(rc) return rc;
	// }

	rc = mosquitto__connect_init(mosq, host, port, keepalive, bind_address);
	if(rc) 
    return rc;

	mosquitto__set_state(mosq, mosq_cs_new);

	return mosquitto__reconnect(mosq, true, properties);
}

int mosquitto_reconnect(struct mosquitto *mosq)
{
	return mosquitto__reconnect(mosq, true, NULL);
}


static int mosquitto__reconnect(struct mosquitto *mosq, bool blocking, const mosquitto_property *properties)
{
	const mosquitto_property *outgoing_properties = NULL;
	mosquitto_property local_property;
	int rc;

	if(!mosq) return MOSQ_ERR_INVAL;
	if(!mosq->host || mosq->port <= 0) return MOSQ_ERR_INVAL;
	if(mosq->protocol != mosq_p_mqtt5 && properties) return MOSQ_ERR_NOT_SUPPORTED;

	if(properties){
		if(properties->client_generated){
			outgoing_properties = properties;
		}else{
			memcpy(&local_property, properties, sizeof(mosquitto_property));
			local_property.client_generated = true;
			local_property.next = NULL;
			outgoing_properties = &local_property;
		}
		// rc = mosquitto_property_check_all(CMD_CONNECT, outgoing_properties);
		// if(rc) return rc;
	}

	pthread_mutex_lock(&mosq->msgtime_mutex);
	mosq->last_msg_in = mosquitto_time();
	mosq->next_msg_out = mosq->last_msg_in + mosq->keepalive;
	pthread_mutex_unlock(&mosq->msgtime_mutex);

	mosq->ping_t = 0;

	packet__cleanup(&mosq->in_packet);

	packet__cleanup_all(mosq);

	message__reconnect_reset(mosq);

	if(mosq->sock != INVALID_SOCKET){
        net__socket_close(mosq); //close socket
    }

#ifdef WITH_SOCKS
	if(mosq->socks5_host){
		rc = net__socket_connect(mosq, mosq->socks5_host, mosq->socks5_port, mosq->bind_address, blocking);
	}else
#endif
	{
		rc = net__socket_connect(mosq, mosq->host, mosq->port, mosq->bind_address, blocking);
	}
	if(rc>0){
		mosquitto__set_state(mosq, mosq_cs_connect_pending);
		return rc;
	}

#ifdef WITH_SOCKS
	if(mosq->socks5_host){
		mosquitto__set_state(mosq, mosq_cs_socks5_new);
		return socks5__send(mosq);
	}else
#endif
	{
		mosquitto__set_state(mosq, mosq_cs_connected);
		rc = send__connect(mosq, mosq->keepalive, mosq->clean_start, outgoing_properties);
		if(rc){
			packet__cleanup_all(mosq);
			net__socket_close(mosq);
			mosquitto__set_state(mosq, mosq_cs_new);
		}
		return rc;
	}
}

///////////////////////////////util_mosq.c///////////////////////////////////

int mosquitto__set_state(struct mosquitto *mosq, enum mosquitto_client_state state)
{               
        pthread_mutex_lock(&mosq->state_mutex);
// #ifdef WITH_BROKER
        // if(mosq->state != mosq_cs_disused)
// #endif  
        {
                mosq->state = state;
        }       
        pthread_mutex_unlock(&mosq->state_mutex);
        
        return MOSQ_ERR_SUCCESS;
}  

enum mosquitto_client_state mosquitto__get_state(struct mosquitto *mosq)
{
        enum mosquitto_client_state state;

        pthread_mutex_lock(&mosq->state_mutex);
        state = mosq->state;
        pthread_mutex_unlock(&mosq->state_mutex);

        return state;
}   

int util__random_bytes(void *bytes, int count)
{
	int rc = MOSQ_ERR_UNKNOWN;

// #ifdef WITH_TLS
// 	if(RAND_bytes(bytes, count) == 1){
// 		rc = MOSQ_ERR_SUCCESS;
// 	}
// #elif defined(HAVE_GETRANDOM)
// 	if(getrandom(bytes, count, 0) == count){
// 		rc = MOSQ_ERR_SUCCESS;
// 	}
// #elif defined(WIN32)
// 	HCRYPTPROV provider;

// 	if(!CryptAcquireContext(&provider, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)){
// 		return MOSQ_ERR_UNKNOWN;
// 	}

// 	if(CryptGenRandom(provider, count, bytes)){
// 		rc = MOSQ_ERR_SUCCESS;
// 	}

// 	CryptReleaseContext(provider, 0);
// #else
	int i;

	for(i=0; i<count; i++){
		((uint8_t *)bytes)[i] = (uint8_t )(random()&0xFF);
	}
	rc = MOSQ_ERR_SUCCESS;
// #endif
	return rc;
}

uint16_t mosquitto__mid_generate(struct mosquitto *mosq)
{                       
        /* FIXME - this would be better with atomic increment, but this is safer
         * for now for a bug fix release.
         *      
         * If this is changed to use atomic increment, callers of this function
         * will have to be aware that they may receive a 0 result, which may not be
         * used as a mid.
         */
        uint16_t mid;
        assert(mosq);
                
        pthread_mutex_lock(&mosq->mid_mutex);
        mosq->last_mid++;
        if(mosq->last_mid == 0) mosq->last_mid++;
        mid = mosq->last_mid;
        pthread_mutex_unlock(&mosq->mid_mutex);
                        
        return mid;
}        

void util__decrement_receive_quota(struct mosquitto *mosq)
{       
        if(mosq->msgs_in.inflight_quota > 0){
                mosq->msgs_in.inflight_quota--;
        }
}       
        
void util__decrement_send_quota(struct mosquitto *mosq)
{               
        if(mosq->msgs_out.inflight_quota > 0){
                mosq->msgs_out.inflight_quota--;
        }               
} 

///////////////////////////////actions.c///////////////////////////////////


int mosquitto_publish(struct mosquitto *mosq, int *mid, const char *topic, int payloadlen, const void *payload, int qos, bool retain)
{
	return mosquitto_publish_v5(mosq, mid, topic, payloadlen, payload, qos, retain, NULL);
}

int mosquitto_publish_v5(struct mosquitto *mosq, int *mid, const char *topic, int payloadlen, const void *payload, int qos, bool retain, const mosquitto_property *properties)
{
	struct mosquitto_message_all *message;
	uint16_t local_mid;
	const mosquitto_property *p;
	const mosquitto_property *outgoing_properties = NULL;
	mosquitto_property *properties_copy = NULL;
	mosquitto_property local_property;
	bool have_topic_alias;
	int rc;
	int tlen = 0;
	uint32_t remaining_length;

	if(!mosq || qos<0 || qos>2) return MOSQ_ERR_INVAL;
	if(mosq->protocol != mosq_p_mqtt5 && properties) return MOSQ_ERR_NOT_SUPPORTED;
	if(qos > mosq->maximum_qos) return MOSQ_ERR_QOS_NOT_SUPPORTED;

	if(properties){
		if(properties->client_generated){
			outgoing_properties = properties;
		}else{
			memcpy(&local_property, properties, sizeof(mosquitto_property));
			local_property.client_generated = true;
			local_property.next = NULL;
			outgoing_properties = &local_property;
		}
		// rc = mosquitto_property_check_all(CMD_PUBLISH, outgoing_properties);
		// if(rc) 
            return rc;
	}

	if(!topic || STREMPTY(topic)){
		if(topic) topic = NULL;

		if(mosq->protocol == mosq_p_mqtt5){
			p = outgoing_properties;
			have_topic_alias = false;
			while(p){
				if(p->identifier == MQTT_PROP_TOPIC_ALIAS){
					have_topic_alias = true;
					break;
				}
				p = p->next;
			}
			if(have_topic_alias == false){
				return MOSQ_ERR_INVAL;
			}
		}else{
			return MOSQ_ERR_INVAL;
		}
	}else{
		tlen = strlen(topic);
		if(mosquitto_validate_utf8(topic, tlen)) return MOSQ_ERR_MALFORMED_UTF8;
		if(payloadlen < 0 || payloadlen > MQTT_MAX_PAYLOAD) return MOSQ_ERR_PAYLOAD_SIZE;
		if(mosquitto_pub_topic_check(topic) != MOSQ_ERR_SUCCESS){
			return MOSQ_ERR_INVAL;
		}
	}

	if(mosq->maximum_packet_size > 0){
		remaining_length = 1 + 2+tlen + payloadlen + property__get_length_all(outgoing_properties);
		if(qos > 0){
			remaining_length++;
		}
		if(packet__check_oversize(mosq, remaining_length)){
			return MOSQ_ERR_OVERSIZE_PACKET;
		}
	}

	local_mid = mosquitto__mid_generate(mosq);
	if(mid){
		*mid = local_mid;
	}

	if(qos == 0){
		return send__publish(mosq, local_mid, topic, payloadlen, payload, qos, retain, false, outgoing_properties, NULL, 0);
	}else{
		if(outgoing_properties){
			rc = mosquitto_property_copy_all(&properties_copy, outgoing_properties);
			if(rc) return rc;
		}
		message = (struct mosquitto_message_all*)calloc(1, sizeof(struct mosquitto_message_all));
		if(!message){
			mosquitto_property_free_all(&properties_copy);
			return MOSQ_ERR_NOMEM;
		}

		message->next = NULL;
		message->timestamp = mosquitto_time();
		message->msg.mid = local_mid;
		if(topic){
			message->msg.topic = strdup(topic);
			if(!message->msg.topic){
				message__cleanup(&message);
				mosquitto_property_free_all(&properties_copy);
				return MOSQ_ERR_NOMEM;
			}
		}
		if(payloadlen){
			message->msg.payloadlen = payloadlen;
			message->msg.payload = malloc(payloadlen*sizeof(uint8_t));
			if(!message->msg.payload){
				message__cleanup(&message);
				mosquitto_property_free_all(&properties_copy);
				return MOSQ_ERR_NOMEM;
			}
			memcpy(message->msg.payload, payload, payloadlen*sizeof(uint8_t));
		}else{
			message->msg.payloadlen = 0;
			message->msg.payload = NULL;
		}
		message->msg.qos = qos;
		message->msg.retain = retain;
		message->dup = false;
		message->properties = properties_copy;

		pthread_mutex_lock(&mosq->msgs_out.mutex);
		message->state = mosq_ms_invalid;
		// message__queue(mosq, message, mosq_md_out);
		pthread_mutex_unlock(&mosq->msgs_out.mutex);
		return MOSQ_ERR_SUCCESS;
	}
}


///////////////////////////////utf8_mosq.c///////////////////////////////////


int mosquitto_validate_utf8(const char *str, int len)
{
	int i;
	int j;
	int codelen;
	int codepoint;
	const unsigned char *ustr = (const unsigned char *)str;

	if(!str) return MOSQ_ERR_INVAL;
	if(len < 0 || len > 65536) return MOSQ_ERR_INVAL;

	for(i=0; i<len; i++){
		if(ustr[i] == 0){
			return MOSQ_ERR_MALFORMED_UTF8;
		}else if(ustr[i] <= 0x7f){
			codelen = 1;
			codepoint = ustr[i];
		}else if((ustr[i] & 0xE0) == 0xC0){
			/* 110xxxxx - 2 byte sequence */
			if(ustr[i] == 0xC0 || ustr[i] == 0xC1){
				/* Invalid bytes */
				return MOSQ_ERR_MALFORMED_UTF8;
			}
			codelen = 2;
			codepoint = (ustr[i] & 0x1F);
		}else if((ustr[i] & 0xF0) == 0xE0){
			// 1110xxxx - 3 byte sequence
			codelen = 3;
			codepoint = (ustr[i] & 0x0F);
		}else if((ustr[i] & 0xF8) == 0xF0){
			// 11110xxx - 4 byte sequence
			if(ustr[i] > 0xF4){
				/* Invalid, this would produce values > 0x10FFFF. */
				return MOSQ_ERR_MALFORMED_UTF8;
			}
			codelen = 4;
			codepoint = (ustr[i] & 0x07);
		}else{
			/* Unexpected continuation byte. */
			return MOSQ_ERR_MALFORMED_UTF8;
		}

		/* Reconstruct full code point */
		if(i == len-codelen+1){
			/* Not enough data */
			return MOSQ_ERR_MALFORMED_UTF8;
		}
		for(j=0; j<codelen-1; j++){
			if((ustr[++i] & 0xC0) != 0x80){
				/* Not a continuation byte */
				return MOSQ_ERR_MALFORMED_UTF8;
			}
			codepoint = (codepoint<<6) | (ustr[i] & 0x3F);
		}
		
		/* Check for UTF-16 high/low surrogates */
		if(codepoint >= 0xD800 && codepoint <= 0xDFFF){
			return MOSQ_ERR_MALFORMED_UTF8;
		}

		/* Check for overlong or out of range encodings */
		/* Checking codelen == 2 isn't necessary here, because it is already
		 * covered above in the C0 and C1 checks.
		 * if(codelen == 2 && codepoint < 0x0080){
		 *	 return MOSQ_ERR_MALFORMED_UTF8;
		 * }else
		*/
		if(codelen == 3 && codepoint < 0x0800){
			return MOSQ_ERR_MALFORMED_UTF8;
		}else if(codelen == 4 && (codepoint < 0x10000 || codepoint > 0x10FFFF)){
			return MOSQ_ERR_MALFORMED_UTF8;
		}

		/* Check for non-characters */
		if(codepoint >= 0xFDD0 && codepoint <= 0xFDEF){
			return MOSQ_ERR_MALFORMED_UTF8;
		}
		if((codepoint & 0xFFFF) == 0xFFFE || (codepoint & 0xFFFF) == 0xFFFF){
			return MOSQ_ERR_MALFORMED_UTF8;
		}
		/* Check for control characters */
		if(codepoint <= 0x001F || (codepoint >= 0x007F && codepoint <= 0x009F)){
			return MOSQ_ERR_MALFORMED_UTF8;
		}
	}
	return MOSQ_ERR_SUCCESS;
}


///////////////////////////////util_topic.c///////////////////////////////////


int mosquitto_pub_topic_check(const char *str)
{
        int len = 0;
#ifdef WITH_BROKER
        int hier_count = 0;
#endif
        while(str && str[0]){
                if(str[0] == '+' || str[0] == '#'){
                        return MOSQ_ERR_INVAL;
                }
#ifdef WITH_BROKER
                else if(str[0] == '/'){
                        hier_count++;
                }
#endif
                len++;
                str = &str[1];
        }
        if(len > 65535) return MOSQ_ERR_INVAL;
#ifdef WITH_BROKER
        if(hier_count > TOPIC_HIERARCHY_LIMIT) return MOSQ_ERR_INVAL;
#endif

        return MOSQ_ERR_SUCCESS;
}


///////////////////////////////property_mosq.c///////////////////////////////////

                
int property__get_length_all(const mosquitto_property *property)
{               
        const mosquitto_property *p;
        int len = 0;    
        
        p = property;
        while(p){
                len += property__get_length(p); 
                p = p->next;
        }       
        return len;     
}               
      
int property__get_length(const mosquitto_property *property)
{
	if(!property) return 0;

	switch(property->identifier){
		/* Byte */
		case MQTT_PROP_PAYLOAD_FORMAT_INDICATOR:
		case MQTT_PROP_REQUEST_PROBLEM_INFORMATION:
		case MQTT_PROP_REQUEST_RESPONSE_INFORMATION:
		case MQTT_PROP_MAXIMUM_QOS:
		case MQTT_PROP_RETAIN_AVAILABLE:
		case MQTT_PROP_WILDCARD_SUB_AVAILABLE:
		case MQTT_PROP_SUBSCRIPTION_ID_AVAILABLE:
		case MQTT_PROP_SHARED_SUB_AVAILABLE:
			return 2; /* 1 (identifier) + 1 byte */

		/* uint16 */
		case MQTT_PROP_SERVER_KEEP_ALIVE:
		case MQTT_PROP_RECEIVE_MAXIMUM:
		case MQTT_PROP_TOPIC_ALIAS_MAXIMUM:
		case MQTT_PROP_TOPIC_ALIAS:
			return 3; /* 1 (identifier) + 2 bytes */

		/* uint32 */
		case MQTT_PROP_MESSAGE_EXPIRY_INTERVAL:
		case MQTT_PROP_WILL_DELAY_INTERVAL:
		case MQTT_PROP_MAXIMUM_PACKET_SIZE:
		case MQTT_PROP_SESSION_EXPIRY_INTERVAL:
			return 5; /* 1 (identifier) + 4 bytes */

		/* varint */
		case MQTT_PROP_SUBSCRIPTION_IDENTIFIER:
			if(property->value.varint < 128){
				return 2;
			}else if(property->value.varint < 16384){
				return 3;
			}else if(property->value.varint < 2097152){
				return 4;
			}else if(property->value.varint < 268435456){
				return 5;
			}else{
				return 0;
			}

		/* binary */
		case MQTT_PROP_CORRELATION_DATA:
		case MQTT_PROP_AUTHENTICATION_DATA:
			return 3 + property->value.bin.len; /* 1 + 2 bytes (len) + X bytes (payload) */

		/* string */
		case MQTT_PROP_CONTENT_TYPE:
		case MQTT_PROP_RESPONSE_TOPIC:
		case MQTT_PROP_ASSIGNED_CLIENT_IDENTIFIER:
		case MQTT_PROP_AUTHENTICATION_METHOD:
		case MQTT_PROP_RESPONSE_INFORMATION:
		case MQTT_PROP_SERVER_REFERENCE:
		case MQTT_PROP_REASON_STRING:
			return 3 + property->value.s.len; /* 1 + 2 bytes (len) + X bytes (string) */

		/* string pair */
		case MQTT_PROP_USER_PROPERTY:
			return 5 + property->value.s.len + property->name.len; /* 1 + 2*(2 bytes (len) + X bytes (string))*/

		default:
			return 0;
	}
	return 0;
}

int property__write(struct mosquitto__packet *packet, const mosquitto_property *property)
{
	int rc;

	rc = packet__write_varint(packet, property->identifier);
	if(rc) return rc;

	switch(property->identifier){
		case MQTT_PROP_PAYLOAD_FORMAT_INDICATOR:
		case MQTT_PROP_REQUEST_PROBLEM_INFORMATION:
		case MQTT_PROP_REQUEST_RESPONSE_INFORMATION:
		case MQTT_PROP_MAXIMUM_QOS:
		case MQTT_PROP_RETAIN_AVAILABLE:
		case MQTT_PROP_WILDCARD_SUB_AVAILABLE:
		case MQTT_PROP_SUBSCRIPTION_ID_AVAILABLE:
		case MQTT_PROP_SHARED_SUB_AVAILABLE:
			packet__write_byte(packet, property->value.i8);
			break;

		case MQTT_PROP_SERVER_KEEP_ALIVE:
		case MQTT_PROP_RECEIVE_MAXIMUM:
		case MQTT_PROP_TOPIC_ALIAS_MAXIMUM:
		case MQTT_PROP_TOPIC_ALIAS:
			packet__write_uint16(packet, property->value.i16);
			break;

		case MQTT_PROP_MESSAGE_EXPIRY_INTERVAL:
		case MQTT_PROP_SESSION_EXPIRY_INTERVAL:
		case MQTT_PROP_WILL_DELAY_INTERVAL:
		case MQTT_PROP_MAXIMUM_PACKET_SIZE:
			packet__write_uint32(packet, property->value.i32);
			break;

		case MQTT_PROP_SUBSCRIPTION_IDENTIFIER:
			return packet__write_varint(packet, property->value.varint);

		case MQTT_PROP_CONTENT_TYPE:
		case MQTT_PROP_RESPONSE_TOPIC:
		case MQTT_PROP_ASSIGNED_CLIENT_IDENTIFIER:
		case MQTT_PROP_AUTHENTICATION_METHOD:
		case MQTT_PROP_RESPONSE_INFORMATION:
		case MQTT_PROP_SERVER_REFERENCE:
		case MQTT_PROP_REASON_STRING:
			packet__write_string(packet, property->value.s.v, property->value.s.len);
			break;

		case MQTT_PROP_AUTHENTICATION_DATA:
		case MQTT_PROP_CORRELATION_DATA:
			packet__write_uint16(packet, property->value.bin.len);
			packet__write_bytes(packet, property->value.bin.v, property->value.bin.len);
			break;

		case MQTT_PROP_USER_PROPERTY:
			packet__write_string(packet, property->name.v, property->name.len);
			packet__write_string(packet, property->value.s.v, property->value.s.len);
			break;

		default:
			log__printf(NULL, MOSQ_LOG_DEBUG, "Unsupported property type: %d", property->identifier);
			return MOSQ_ERR_INVAL;
	}

	return MOSQ_ERR_SUCCESS;
}

int property__write_all(struct mosquitto__packet *packet, const mosquitto_property *properties, bool write_len)
{       
        int rc; 
        const mosquitto_property *p;
                
        if(write_len){
                rc = packet__write_varint(packet, property__get_length_all(properties));
                if(rc) return rc;
        }

        p = properties;
        while(p){
                rc = property__write(packet, p);
                if(rc) return rc;
                p = p->next;
        }               
                
        return MOSQ_ERR_SUCCESS;
} 

void property__free(mosquitto_property **property)
{       
        if(!property || !(*property)) return;
        
        switch((*property)->identifier){
                case MQTT_PROP_CONTENT_TYPE:
                case MQTT_PROP_RESPONSE_TOPIC:
                case MQTT_PROP_ASSIGNED_CLIENT_IDENTIFIER:
                case MQTT_PROP_AUTHENTICATION_METHOD:
                case MQTT_PROP_RESPONSE_INFORMATION:
                case MQTT_PROP_SERVER_REFERENCE:
                case MQTT_PROP_REASON_STRING:
                        free((*property)->value.s.v);
                        break;
                
                case MQTT_PROP_AUTHENTICATION_DATA:
                case MQTT_PROP_CORRELATION_DATA:
                        free((*property)->value.bin.v);
                        break;
                
                case MQTT_PROP_USER_PROPERTY:
                        free((*property)->name.v);
                        free((*property)->value.s.v);
                        break;
                
                case MQTT_PROP_PAYLOAD_FORMAT_INDICATOR:
                case MQTT_PROP_MESSAGE_EXPIRY_INTERVAL:
                case MQTT_PROP_SUBSCRIPTION_IDENTIFIER:
                case MQTT_PROP_SESSION_EXPIRY_INTERVAL:
                case MQTT_PROP_SERVER_KEEP_ALIVE:
                case MQTT_PROP_REQUEST_PROBLEM_INFORMATION:
                case MQTT_PROP_WILL_DELAY_INTERVAL:
                case MQTT_PROP_REQUEST_RESPONSE_INFORMATION:
                case MQTT_PROP_RECEIVE_MAXIMUM:
                case MQTT_PROP_TOPIC_ALIAS_MAXIMUM:
                case MQTT_PROP_TOPIC_ALIAS:
                case MQTT_PROP_MAXIMUM_QOS:
                case MQTT_PROP_RETAIN_AVAILABLE:
                case MQTT_PROP_MAXIMUM_PACKET_SIZE:
                case MQTT_PROP_WILDCARD_SUB_AVAILABLE:
                case MQTT_PROP_SUBSCRIPTION_ID_AVAILABLE:
                case MQTT_PROP_SHARED_SUB_AVAILABLE:
                        /* Nothing to free */
                        break;
        }
        
        free(*property);
        *property = NULL;
}


void mosquitto_property_free_all(mosquitto_property **property)
{
        mosquitto_property *p, *next;

        if(!property) return;

        p = *property;
        while(p){
                next = p->next;
                property__free(&p);
                p = next;
        }
        *property = NULL;
}

int mosquitto_property_copy_all(mosquitto_property **dest, const mosquitto_property *src)
{
	mosquitto_property *pnew, *plast = NULL;

	if(!src) return MOSQ_ERR_SUCCESS;
	if(!dest) return MOSQ_ERR_INVAL;

	*dest = NULL;

	while(src){
		pnew = (mosquitto_property *)calloc(1, sizeof(mosquitto_property));
		if(!pnew){
			mosquitto_property_free_all(dest);
			return MOSQ_ERR_NOMEM;
		}
		if(plast){
			plast->next = pnew;
		}else{
			*dest = pnew;
		}
		plast = pnew;

		pnew->identifier = src->identifier;
		switch(pnew->identifier){
			case MQTT_PROP_PAYLOAD_FORMAT_INDICATOR:
			case MQTT_PROP_REQUEST_PROBLEM_INFORMATION:
			case MQTT_PROP_REQUEST_RESPONSE_INFORMATION:
			case MQTT_PROP_MAXIMUM_QOS:
			case MQTT_PROP_RETAIN_AVAILABLE:
			case MQTT_PROP_WILDCARD_SUB_AVAILABLE:
			case MQTT_PROP_SUBSCRIPTION_ID_AVAILABLE:
			case MQTT_PROP_SHARED_SUB_AVAILABLE:
				pnew->value.i8 = src->value.i8;
				break;

			case MQTT_PROP_SERVER_KEEP_ALIVE:
			case MQTT_PROP_RECEIVE_MAXIMUM:
			case MQTT_PROP_TOPIC_ALIAS_MAXIMUM:
			case MQTT_PROP_TOPIC_ALIAS:
				pnew->value.i16 = src->value.i16;
				break;

			case MQTT_PROP_MESSAGE_EXPIRY_INTERVAL:
			case MQTT_PROP_SESSION_EXPIRY_INTERVAL:
			case MQTT_PROP_WILL_DELAY_INTERVAL:
			case MQTT_PROP_MAXIMUM_PACKET_SIZE:
				pnew->value.i32 = src->value.i32;
				break;

			case MQTT_PROP_SUBSCRIPTION_IDENTIFIER:
				pnew->value.varint = src->value.varint;
				break;

			case MQTT_PROP_CONTENT_TYPE:
			case MQTT_PROP_RESPONSE_TOPIC:
			case MQTT_PROP_ASSIGNED_CLIENT_IDENTIFIER:
			case MQTT_PROP_AUTHENTICATION_METHOD:
			case MQTT_PROP_RESPONSE_INFORMATION:
			case MQTT_PROP_SERVER_REFERENCE:
			case MQTT_PROP_REASON_STRING:
				pnew->value.s.len = src->value.s.len;
				pnew->value.s.v = strdup(src->value.s.v);
				if(!pnew->value.s.v){
					mosquitto_property_free_all(dest);
					return MOSQ_ERR_NOMEM;
				}
				break;

			case MQTT_PROP_AUTHENTICATION_DATA:
			case MQTT_PROP_CORRELATION_DATA:
				pnew->value.bin.len = src->value.bin.len;
				pnew->value.bin.v = (char*)malloc(pnew->value.bin.len);
				if(!pnew->value.bin.v){
					mosquitto_property_free_all(dest);
					return MOSQ_ERR_NOMEM;
				}
				memcpy(pnew->value.bin.v, src->value.bin.v, pnew->value.bin.len);
				break;

			case MQTT_PROP_USER_PROPERTY:
				pnew->value.s.len = src->value.s.len;
				pnew->value.s.v = strdup(src->value.s.v);
				if(!pnew->value.s.v){
					mosquitto_property_free_all(dest);
					return MOSQ_ERR_NOMEM;
				}

				pnew->name.len = src->name.len;
				pnew->name.v = strdup(src->name.v);
				if(!pnew->name.v){
					mosquitto_property_free_all(dest);
					return MOSQ_ERR_NOMEM;
				}
				break;

			default:
				mosquitto_property_free_all(dest);
				return MOSQ_ERR_INVAL;
		}

		src = src->next;
	}

	return MOSQ_ERR_SUCCESS;
}

int mosquitto_property_check_all(int command, const mosquitto_property *properties)
{       
        const mosquitto_property *p, *tail;
        int rc;
        
        p = properties;
        
        while(p){
                /* Validity checks */
                if(p->identifier == MQTT_PROP_REQUEST_PROBLEM_INFORMATION
                                || p->identifier == MQTT_PROP_REQUEST_RESPONSE_INFORMATION
                                || p->identifier == MQTT_PROP_MAXIMUM_QOS
                                || p->identifier == MQTT_PROP_RETAIN_AVAILABLE
                                || p->identifier == MQTT_PROP_WILDCARD_SUB_AVAILABLE
                                || p->identifier == MQTT_PROP_SUBSCRIPTION_ID_AVAILABLE
                                || p->identifier == MQTT_PROP_SHARED_SUB_AVAILABLE){
                        
                        if(p->value.i8 > 1){
                                return MOSQ_ERR_PROTOCOL;
                        }
                }else if(p->identifier == MQTT_PROP_MAXIMUM_PACKET_SIZE){
                        if( p->value.i32 == 0){
                                return MOSQ_ERR_PROTOCOL;
                        }
                }else if(p->identifier == MQTT_PROP_RECEIVE_MAXIMUM
                                || p->identifier == MQTT_PROP_TOPIC_ALIAS){
                        
                        if(p->value.i16 == 0){
                                return MOSQ_ERR_PROTOCOL;
                        }
                }
                
                /* Check for properties on incorrect commands */
                rc = mosquitto_property_check_command(command, p->identifier);
                if(rc) return rc;
                
                /* Check for duplicates */
                tail = p->next;
                while(tail){
                        if(p->identifier == tail->identifier
                                        && p->identifier != MQTT_PROP_USER_PROPERTY){
                                
                                return MOSQ_ERR_DUPLICATE_PROPERTY;
                        }
                        tail = tail->next;
                }
                
                p = p->next;
        }
        
        return MOSQ_ERR_SUCCESS;
}

const mosquitto_property *mosquitto_property_read_int16(const mosquitto_property *proplist, int identifier, uint16_t *value, bool skip_first)
{ 
        const mosquitto_property *p;
        if(!proplist) return NULL;
                        
        p = property__get_property(proplist, identifier, skip_first);
        if(!p) return NULL;
        if(p->identifier != MQTT_PROP_SERVER_KEEP_ALIVE
                        && p->identifier != MQTT_PROP_RECEIVE_MAXIMUM
                        && p->identifier != MQTT_PROP_TOPIC_ALIAS_MAXIMUM
                        && p->identifier != MQTT_PROP_TOPIC_ALIAS){
                return NULL;
        }       
                
        if(value) *value = p->value.i16;
        
        return p;
}    

const mosquitto_property *property__get_property(const mosquitto_property *proplist, int identifier, bool skip_first)
{
        const mosquitto_property *p;
        bool is_first = true;

        p = proplist;

        while(p){
                if(p->identifier == identifier){
                        if(!is_first || !skip_first){
                                return p;
                        }
                        is_first = false;
                }
                p = p->next;
        }
        return NULL;
}

int mosquitto_property_add_int16(mosquitto_property **proplist, int identifier, uint16_t value)
{
        mosquitto_property *prop;
                
        if(!proplist) return MOSQ_ERR_INVAL;
        if(identifier != MQTT_PROP_SERVER_KEEP_ALIVE
                        && identifier != MQTT_PROP_RECEIVE_MAXIMUM
                        && identifier != MQTT_PROP_TOPIC_ALIAS_MAXIMUM
                        && identifier != MQTT_PROP_TOPIC_ALIAS){
                return MOSQ_ERR_INVAL;
        } 

        prop = (mosquitto_property*)calloc(1, sizeof(mosquitto_property));
        if(!prop) return MOSQ_ERR_NOMEM;
        
        prop->client_generated = true;
        prop->identifier = identifier;
        prop->value.i16 = value;
                
        property__add(proplist, prop);
        return MOSQ_ERR_SUCCESS;
}   

static void property__add(mosquitto_property **proplist, struct mqtt5__property *prop)
{
        mosquitto_property *p;

        if(!(*proplist)){
                *proplist = prop;
        }

        p = *proplist;
        while(p->next){
                p = p->next;
        }
        p->next = prop;
        prop->next = NULL;
}

int mosquitto_property_check_command(int command, int identifier)
{
	switch(identifier){
		case MQTT_PROP_PAYLOAD_FORMAT_INDICATOR:
		case MQTT_PROP_MESSAGE_EXPIRY_INTERVAL:
		case MQTT_PROP_CONTENT_TYPE:
		case MQTT_PROP_RESPONSE_TOPIC:
		case MQTT_PROP_CORRELATION_DATA:
			if(command != CMD_PUBLISH && command != CMD_WILL){
				return MOSQ_ERR_PROTOCOL;
			}
			break;

		case MQTT_PROP_SUBSCRIPTION_IDENTIFIER:
			if(command != CMD_PUBLISH && command != CMD_SUBSCRIBE){
				return MOSQ_ERR_PROTOCOL;
			}
			break;

		case MQTT_PROP_SESSION_EXPIRY_INTERVAL:
			if(command != CMD_CONNECT && command != CMD_CONNACK && command != CMD_DISCONNECT){
				return MOSQ_ERR_PROTOCOL;
			}
			break;

		case MQTT_PROP_AUTHENTICATION_METHOD:
		case MQTT_PROP_AUTHENTICATION_DATA:
			if(command != CMD_CONNECT && command != CMD_CONNACK && command != CMD_AUTH){
				return MOSQ_ERR_PROTOCOL;
			}
			break;

		case MQTT_PROP_ASSIGNED_CLIENT_IDENTIFIER:
		case MQTT_PROP_SERVER_KEEP_ALIVE:
		case MQTT_PROP_RESPONSE_INFORMATION:
		case MQTT_PROP_MAXIMUM_QOS:
		case MQTT_PROP_RETAIN_AVAILABLE:
		case MQTT_PROP_WILDCARD_SUB_AVAILABLE:
		case MQTT_PROP_SUBSCRIPTION_ID_AVAILABLE:
		case MQTT_PROP_SHARED_SUB_AVAILABLE:
			if(command != CMD_CONNACK){
				return MOSQ_ERR_PROTOCOL;
			}
			break;

		case MQTT_PROP_WILL_DELAY_INTERVAL:
			if(command != CMD_WILL){
				return MOSQ_ERR_PROTOCOL;
			}
			break;

		case MQTT_PROP_REQUEST_PROBLEM_INFORMATION:
		case MQTT_PROP_REQUEST_RESPONSE_INFORMATION:
			if(command != CMD_CONNECT){
				return MOSQ_ERR_PROTOCOL;
			}
			break;

		case MQTT_PROP_SERVER_REFERENCE:
			if(command != CMD_CONNACK && command != CMD_DISCONNECT){
				return MOSQ_ERR_PROTOCOL;
			}
			break;

		case MQTT_PROP_REASON_STRING:
			if(command == CMD_CONNECT || command == CMD_PUBLISH || command == CMD_SUBSCRIBE || command == CMD_UNSUBSCRIBE){
				return MOSQ_ERR_PROTOCOL;
			}
			break;

		case MQTT_PROP_RECEIVE_MAXIMUM:
		case MQTT_PROP_TOPIC_ALIAS_MAXIMUM:
		case MQTT_PROP_MAXIMUM_PACKET_SIZE:
			if(command != CMD_CONNECT && command != CMD_CONNACK){
				return MOSQ_ERR_PROTOCOL;
			}
			break;

		case MQTT_PROP_TOPIC_ALIAS:
			if(command != CMD_PUBLISH){
				return MOSQ_ERR_PROTOCOL;
			}
			break;

		case MQTT_PROP_USER_PROPERTY:
			break;

		default:
			return MOSQ_ERR_PROTOCOL;
	}
	return MOSQ_ERR_SUCCESS;
}

///////////////////////////////packet_mosq.c///////////////////////////////////

void packet__cleanup(struct mosquitto__packet *packet)
{       
        if(!packet) return; 
                
        /* Free data and reset values */
        packet->command = 0;
        packet->remaining_count = 0;
        packet->remaining_mult = 1;
        packet->remaining_length = 0;
        free(packet->payload);
        packet->payload = NULL;
        packet->to_process = 0;
        packet->pos = 0;
}

int packet__queue(struct mosquitto *mosq, struct mosquitto__packet *packet)
{
// #ifndef WITH_BROKER
	char sockpair_data = 0;
// #endif
	assert(mosq);
	assert(packet);

	packet->pos = 0;
	packet->to_process = packet->packet_length;

	packet->next = NULL;
	pthread_mutex_lock(&mosq->out_packet_mutex);
	if(mosq->out_packet){
		mosq->out_packet_last->next = packet;
	}else{
		mosq->out_packet = packet;
	}
	mosq->out_packet_last = packet;
	pthread_mutex_unlock(&mosq->out_packet_mutex);
// #ifdef WITH_BROKER
// #  ifdef WITH_WEBSOCKETS
// 	if(mosq->wsi){
// 		libwebsocket_callback_on_writable(mosq->ws_context, mosq->wsi);
// 		return MOSQ_ERR_SUCCESS;
// 	}else{
// 		return packet__write(mosq);
// 	}
// #  else
	return packet__write(mosq);
// #  endif
// #else

// 	/* Write a single byte to sockpairW (connected to sockpairR) to break out
// 	 * of select() if in threaded mode. */
// 	if(mosq->sockpairW != INVALID_SOCKET){
// // #ifndef WIN32
// // 		if(write(mosq->sockpairW, &sockpair_data, 1)){
// // 		}
// // #else
// 		send(mosq->sockpairW, &sockpair_data, 1, 0);
// // #endif
// 	}

// 	if(mosq->in_callback == false && mosq->threaded == mosq_ts_none){
// 		return packet__write(mosq);
// 	}else{
// 		return MOSQ_ERR_SUCCESS;
// 	}
// #endif
}

int packet__check_oversize(struct mosquitto *mosq, uint32_t remaining_length)
{               
        uint32_t len;   
                
        if(mosq->maximum_packet_size == 0) return MOSQ_ERR_SUCCESS;
                        
        len = remaining_length + packet__varint_bytes(remaining_length);
        if(len > mosq->maximum_packet_size){
                return MOSQ_ERR_OVERSIZE_PACKET;
        }else{
                return MOSQ_ERR_SUCCESS;
        }       
}    

int packet__alloc(struct mosquitto__packet *packet)
{
	uint8_t remaining_bytes[5], byte;
	uint32_t remaining_length;
	int i;

	assert(packet);

	remaining_length = packet->remaining_length;
	packet->payload = NULL;
	packet->remaining_count = 0;
	do{
		byte = remaining_length % 128;
		remaining_length = remaining_length / 128;
		/* If there are more digits to encode, set the top bit of this digit */
		if(remaining_length > 0){
			byte = byte | 0x80;
		}
		remaining_bytes[packet->remaining_count] = byte;
		packet->remaining_count++;
	}while(remaining_length > 0 && packet->remaining_count < 5);
	if(packet->remaining_count == 5) return MOSQ_ERR_PAYLOAD_SIZE;
	packet->packet_length = packet->remaining_length + 1 + packet->remaining_count;
// #ifdef WITH_WEBSOCKETS
// 	packet->payload = (uint8_t*)malloc(sizeof(uint8_t)*packet->packet_length + LWS_SEND_BUFFER_PRE_PADDING + LWS_SEND_BUFFER_POST_PADDING);
// #else
	packet->payload = (uint8_t*)malloc(sizeof(uint8_t)*packet->packet_length);
// #endif
	if(!packet->payload) return MOSQ_ERR_NOMEM;

	packet->payload[0] = packet->command;
	for(i=0; i<packet->remaining_count; i++){
		packet->payload[i+1] = remaining_bytes[i];
	}
	packet->pos = 1 + packet->remaining_count;

	return MOSQ_ERR_SUCCESS;
}

int packet__write(struct mosquitto *mosq)
{
	ssize_t write_length;
	struct mosquitto__packet *packet;
	int state;

	if(!mosq) return MOSQ_ERR_INVAL;
	if(mosq->sock == INVALID_SOCKET) return MOSQ_ERR_NO_CONN;

	pthread_mutex_lock(&mosq->current_out_packet_mutex);
	pthread_mutex_lock(&mosq->out_packet_mutex);
	if(mosq->out_packet && !mosq->current_out_packet){
		mosq->current_out_packet = mosq->out_packet;
		mosq->out_packet = mosq->out_packet->next;
		if(!mosq->out_packet){
			mosq->out_packet_last = NULL;
		}
	}
	pthread_mutex_unlock(&mosq->out_packet_mutex);

	state = mosquitto__get_state(mosq);
#if defined(WITH_TLS) && !defined(WITH_BROKER)
	if((state == mosq_cs_connect_pending) || mosq->want_connect){
#else
	if(state == mosq_cs_connect_pending){
#endif
		pthread_mutex_unlock(&mosq->current_out_packet_mutex);
		return MOSQ_ERR_SUCCESS;
	}

	while(mosq->current_out_packet){
		packet = mosq->current_out_packet;

		while(packet->to_process > 0){
			write_length = net__write(mosq, &(packet->payload[packet->pos]), packet->to_process);
			if(write_length > 0){
				G_BYTES_SENT_INC(write_length);
				packet->to_process -= write_length;
				packet->pos += write_length;
			}else{
// #ifdef WIN32
// 				errno = WSAGetLastError();
// #endif
				if(errno == EAGAIN || errno == EWOULDBLOCK
// #ifdef WIN32
// 						|| errno == WSAENOTCONN
// #endif
						){
					pthread_mutex_unlock(&mosq->current_out_packet_mutex);
					return MOSQ_ERR_SUCCESS;
				}else{
					pthread_mutex_unlock(&mosq->current_out_packet_mutex);
					switch(errno){
						case ECONNRESET:
							return MOSQ_ERR_CONN_LOST;
						default:
							return MOSQ_ERR_ERRNO;
					}
				}
			}
		}

		G_MSGS_SENT_INC(1);
		if(((packet->command)&0xF6) == CMD_PUBLISH){
			G_PUB_MSGS_SENT_INC(1);
#ifndef WITH_BROKER
			pthread_mutex_lock(&mosq->callback_mutex);
			if(mosq->on_publish){
				/* This is a QoS=0 message */
				mosq->in_callback = true;
				mosq->on_publish(mosq, mosq->userdata, packet->mid);
				mosq->in_callback = false;
			}
			if(mosq->on_publish_v5){
				/* This is a QoS=0 message */
				mosq->in_callback = true;
				mosq->on_publish_v5(mosq, mosq->userdata, packet->mid, 0, NULL);
				mosq->in_callback = false;
			}
			pthread_mutex_unlock(&mosq->callback_mutex);
		}else if(((packet->command)&0xF0) == CMD_DISCONNECT){
			do_client_disconnect(mosq, MOSQ_ERR_SUCCESS, NULL);
			packet__cleanup(packet);
			free(packet);
			return MOSQ_ERR_SUCCESS;
#endif
		}

		/* Free data and reset values */
		pthread_mutex_lock(&mosq->out_packet_mutex);
		mosq->current_out_packet = mosq->out_packet;
		if(mosq->out_packet){
			mosq->out_packet = mosq->out_packet->next;
			if(!mosq->out_packet){
				mosq->out_packet_last = NULL;
			}
		}
		pthread_mutex_unlock(&mosq->out_packet_mutex);

		packet__cleanup(packet);
		free(packet);

		pthread_mutex_lock(&mosq->msgtime_mutex);
		mosq->next_msg_out = mosquitto_time() + mosq->keepalive;
		pthread_mutex_unlock(&mosq->msgtime_mutex);
	}
	pthread_mutex_unlock(&mosq->current_out_packet_mutex);
	return MOSQ_ERR_SUCCESS;
}

void packet__cleanup_all(struct mosquitto *mosq)
{               
        struct mosquitto__packet *packet;
                
        pthread_mutex_lock(&mosq->current_out_packet_mutex);
        pthread_mutex_lock(&mosq->out_packet_mutex);
        
        /* Out packet cleanup */
        if(mosq->out_packet && !mosq->current_out_packet){
                mosq->current_out_packet = mosq->out_packet;
                mosq->out_packet = mosq->out_packet->next;
        }
        while(mosq->current_out_packet){
                packet = mosq->current_out_packet;
                /* Free data and reset values */
                mosq->current_out_packet = mosq->out_packet;
                if(mosq->out_packet){
                        mosq->out_packet = mosq->out_packet->next;
                }
    
                packet__cleanup(packet);
                free(packet);
        }
                
        packet__cleanup(&mosq->in_packet);
        
        pthread_mutex_unlock(&mosq->out_packet_mutex);
        pthread_mutex_unlock(&mosq->current_out_packet_mutex);
}



///////////////////////////////packet_datatypes.c///////////////////////////////////


int packet__varint_bytes(int32_t word)
{
        if(word < 128){
                return 1;
        }else if(word < 16384){
                return 2;
        }else if(word < 2097152){
                return 3;
        }else if(word < 268435456){
                return 4;
        }else{
                return 5;
        }
} 

void packet__write_string(struct mosquitto__packet *packet, const char *str, uint16_t length)
{       
        assert(packet);
        packet__write_uint16(packet, length);
        packet__write_bytes(packet, str, length);
}  

void packet__write_uint16(struct mosquitto__packet *packet, uint16_t word)
{
        packet__write_byte(packet, MOSQ_MSB(word));
        packet__write_byte(packet, MOSQ_LSB(word));
}

void packet__write_uint32(struct mosquitto__packet *packet, uint32_t word)
{                       
        packet__write_byte(packet, (word & 0xFF000000) >> 24);
        packet__write_byte(packet, (word & 0x00FF0000) >> 16);
        packet__write_byte(packet, (word & 0x0000FF00) >> 8);
        packet__write_byte(packet, (word & 0x000000FF));
}  

void packet__write_byte(struct mosquitto__packet *packet, uint8_t byte)
{
        assert(packet);
        assert(packet->pos+1 <= packet->packet_length);

        packet->payload[packet->pos] = byte;
        packet->pos++;
}

int packet__write_varint(struct mosquitto__packet *packet, int32_t word)
{       
        uint8_t byte;
        int count = 0;
                
        do{
                byte = word % 128;
                word = word / 128;
                /* If there are more digits to encode, set the top bit of this digit */
                if(word > 0){
                        byte = byte | 0x80;
                }
                packet__write_byte(packet, byte);
                count++;
        }while(word > 0 && count < 5);
        
        if(count == 5){
                return MOSQ_ERR_PROTOCOL;
        }
        return MOSQ_ERR_SUCCESS;
}  

void packet__write_bytes(struct mosquitto__packet *packet, const void *bytes, uint32_t count)
{
        assert(packet);
        assert(packet->pos+count <= packet->packet_length);

        memcpy(&(packet->payload[packet->pos]), bytes, count);
        packet->pos += count;
}


///////////////////////////////send_publish.c///////////////////////////////////


int send__publish(struct mosquitto *mosq, uint16_t mid, const char *topic, uint32_t payloadlen, const void *payload, int qos, bool retain, bool dup, const mosquitto_property *cmsg_props, const mosquitto_property *store_props, uint32_t expiry_interval)
{
#ifdef WITH_BROKER
	size_t len;
#ifdef WITH_BRIDGE
	int i;
	struct mosquitto__bridge_topic *cur_topic;
	bool match;
	int rc;
	char *mapped_topic = NULL;
	char *topic_temp = NULL;
#endif
#endif
	assert(mosq);

#if defined(WITH_BROKER) && defined(WITH_WEBSOCKETS)
	if(mosq->sock == INVALID_SOCKET && !mosq->wsi) return MOSQ_ERR_NO_CONN;
#else
	if(mosq->sock == INVALID_SOCKET) return MOSQ_ERR_NO_CONN;
#endif

#ifdef WITH_BROKER
	if(mosq->listener && mosq->listener->mount_point){
		len = strlen(mosq->listener->mount_point);
		if(len < strlen(topic)){
			topic += len;
		}else{
			/* Invalid topic string. Should never happen, but silently swallow the message anyway. */
			return MOSQ_ERR_SUCCESS;
		}
	}
#ifdef WITH_BRIDGE
// 	if(mosq->bridge && mosq->bridge->topics && mosq->bridge->topic_remapping){
// 		for(i=0; i<mosq->bridge->topic_count; i++){
// 			cur_topic = &mosq->bridge->topics[i];
// 			if((cur_topic->direction == bd_both || cur_topic->direction == bd_out)
// 					&& (cur_topic->remote_prefix || cur_topic->local_prefix)){
// 				/* Topic mapping required on this topic if the message matches */

// 				rc = mosquitto_topic_matches_sub(cur_topic->local_topic, topic, &match);
// 				if(rc){
// 					return rc;
// 				}
// 				if(match){
// 					mapped_topic = strdup(topic);
// 					if(!mapped_topic) return MOSQ_ERR_NOMEM;
// 					if(cur_topic->local_prefix){
// 						/* This prefix needs removing. */
// 						if(!strncmp(cur_topic->local_prefix, mapped_topic, strlen(cur_topic->local_prefix))){
// 							topic_temp = strdup(mapped_topic+strlen(cur_topic->local_prefix));
// 							free(mapped_topic);
// 							if(!topic_temp){
// 								return MOSQ_ERR_NOMEM;
// 							}
// 							mapped_topic = topic_temp;
// 						}
// 					}

// 					if(cur_topic->remote_prefix){
// 						/* This prefix needs adding. */
// 						len = strlen(mapped_topic) + strlen(cur_topic->remote_prefix)+1;
// 						topic_temp = malloc(len+1);
// 						if(!topic_temp){
// 							free(mapped_topic);
// 							return MOSQ_ERR_NOMEM;
// 						}
// 						snprintf(topic_temp, len, "%s%s", cur_topic->remote_prefix, mapped_topic);
// 						topic_temp[len] = '\0';
// 						free(mapped_topic);
// 						mapped_topic = topic_temp;
// 					}
					log__printf(NULL, MOSQ_LOG_DEBUG, "Sending PUBLISH to %s (d%d, q%d, r%d, m%d, '%s', ... (%ld bytes))", mosq->id, dup, qos, retain, mid, mapped_topic, (long)payloadlen);
// 					G_PUB_BYTES_SENT_INC(payloadlen);
// 					rc =  send__real_publish(mosq, mid, mapped_topic, payloadlen, payload, qos, retain, dup, cmsg_props, store_props, expiry_interval);
// 					free(mapped_topic);
// 					return rc;
// 				}
// 			}
// 		}
// 	}
#endif
	log__printf(NULL, MOSQ_LOG_DEBUG, "Sending PUBLISH to %s (d%d, q%d, r%d, m%d, '%s', ... (%ld bytes))", mosq->id, dup, qos, retain, mid, topic, (long)payloadlen);
	G_PUB_BYTES_SENT_INC(payloadlen);
#else
	log__printf(mosq, MOSQ_LOG_DEBUG, "Client %s sending PUBLISH (d%d, q%d, r%d, m%d, '%s', ... (%ld bytes))", mosq->id, dup, qos, retain, mid, topic, (long)payloadlen);
#endif

	return send__real_publish(mosq, mid, topic, payloadlen, payload, qos, retain, dup, cmsg_props, store_props, expiry_interval);
}


int send__real_publish(struct mosquitto *mosq, uint16_t mid, const char *topic, uint32_t payloadlen, const void *payload, int qos, bool retain, bool dup, const mosquitto_property *cmsg_props, const mosquitto_property *store_props, uint32_t expiry_interval)
{
	struct mosquitto__packet *packet = NULL;
	int packetlen;
	int proplen = 0, varbytes;
	int rc;
	mosquitto_property expiry_prop;

	assert(mosq);

	if(topic){
		packetlen = 2+strlen(topic) + payloadlen;
	}else{
		packetlen = 2 + payloadlen;
	}
	if(qos > 0) packetlen += 2; /* For message id */
	if(mosq->protocol == mosq_p_mqtt5){
		proplen = 0;
		proplen += property__get_length_all(cmsg_props);
		proplen += property__get_length_all(store_props);
		if(expiry_interval > 0){
			expiry_prop.next = NULL;
			expiry_prop.value.i32 = expiry_interval;
			expiry_prop.identifier = MQTT_PROP_MESSAGE_EXPIRY_INTERVAL;
			expiry_prop.client_generated = false;

			proplen += property__get_length_all(&expiry_prop);
		}

		varbytes = packet__varint_bytes(proplen);
		if(varbytes > 4){
			/* FIXME - Properties too big, don't publish any - should remove some first really */
			cmsg_props = NULL;
			store_props = NULL;
			expiry_interval = 0;
		}else{
			packetlen += proplen + varbytes;
		}
	}
	if(packet__check_oversize(mosq, packetlen)){
#ifdef WITH_BROKER
		log__printf(NULL, MOSQ_LOG_NOTICE, "Dropping too large outgoing PUBLISH for %s (%d bytes)", mosq->id, packetlen);
#else
		log__printf(NULL, MOSQ_LOG_NOTICE, "Dropping too large outgoing PUBLISH (%d bytes)", packetlen);
#endif
		return MOSQ_ERR_OVERSIZE_PACKET;
	}

	packet = (struct mosquitto__packet*)calloc(1, sizeof(struct mosquitto__packet));
	if(!packet) return MOSQ_ERR_NOMEM;

	packet->mid = mid;
	packet->command = CMD_PUBLISH | ((dup&0x1)<<3) | (qos<<1) | retain;
	packet->remaining_length = packetlen;
	rc = packet__alloc(packet);
	if(rc){
		free(packet);
		return rc;
	}
	/* Variable header (topic string) */
	if(topic){
		packet__write_string(packet, topic, strlen(topic));
	}else{
		packet__write_uint16(packet, 0);
	}
	if(qos > 0){
		packet__write_uint16(packet, mid);
	}

	if(mosq->protocol == mosq_p_mqtt5){
		packet__write_varint(packet, proplen);
		property__write_all(packet, cmsg_props, false);
		property__write_all(packet, store_props, false);
		if(expiry_interval > 0){
			property__write_all(packet, &expiry_prop, false);
		}
	}

	/* Payload */
	if(payloadlen){
		packet__write_bytes(packet, payload, payloadlen);
	}

	return packet__queue(mosq, packet);
}



int log__printf(struct mosquitto *mosq, int priority, const char *fmt, ...)
{                                       
        va_list va;
        char *s;                        
        int len;                                
                                                
        assert(mosq);
        assert(fmt);                            
                                                
        pthread_mutex_lock(&mosq->log_callback_mutex);  
        if(mosq->on_log){                               
                len = strlen(fmt) + 500;        
                s = (char*)malloc(len*sizeof(char));
                if(!s){
                        pthread_mutex_unlock(&mosq->log_callback_mutex);
                        return MOSQ_ERR_NOMEM;  
                }                               
                                        
                va_start(va, fmt);      
                vsnprintf(s, len, fmt, va);
                va_end(va);
                s[len-1] = '\0'; /* Ensure string is null terminated. */
                                        
                mosq->on_log(mosq, mosq->userdata, priority, s);

                free(s);
        }
        pthread_mutex_unlock(&mosq->log_callback_mutex);

        return MOSQ_ERR_SUCCESS;
}


///////////////////////////////time_mosq.c///////////////////////////////////


time_t mosquitto_time(void)
{               
#ifdef WIN32    
        return GetTickCount64()/1000;
#elif _POSIX_TIMERS>0 && defined(_POSIX_MONOTONIC_CLOCK)
        struct timespec tp;
                                
        clock_gettime(CLOCK_MONOTONIC, &tp);
        return tp.tv_sec;       
#elif defined(__APPLE__)
        static mach_timebase_info_data_t tb;
    uint64_t ticks;
        uint64_t sec;   
                        
        ticks = mach_absolute_time();
                                
        if(tb.denom == 0){      
                mach_timebase_info(&tb);
        }
        sec = ticks*tb.numer/tb.denom/1000000000;

        return (time_t)sec;
#else
        return time(NULL);
#endif
}


///////////////////////////////messages_mosq.c///////////////////////////////////

void message__cleanup_all(struct mosquitto *mosq)
{
        struct mosquitto_message_all *tail, *tmp;
        
        assert(mosq); 

        DL_FOREACH_SAFE(mosq->msgs_in.inflight, tail, tmp){
                DL_DELETE(mosq->msgs_in.inflight, tail);
                message__cleanup(&tail);
        }
        DL_FOREACH_SAFE(mosq->msgs_out.inflight, tail, tmp){
                DL_DELETE(mosq->msgs_out.inflight, tail);
                message__cleanup(&tail);
        }
}

void message__cleanup(struct mosquitto_message_all **message)
{                               
        struct mosquitto_message_all *msg;
                
        if(!message || !*message) return;
                        
        msg = *message; 
                        
        free(msg->msg.topic);
        free(msg->msg.payload);
        mosquitto_property_free_all(&msg->properties);
        free(msg);
}  

// int message__queue(struct mosquitto *mosq, struct mosquitto_message_all *message, enum mosquitto_msg_direction dir)           
// {                               
//         /* mosq->*_message_mutex should be locked before entering this function */
//         assert(mosq);   
//         assert(message);
//         assert(message->msg.qos != 0);
                        
//         if(dir == mosq_md_out){
//                 DL_APPEND(mosq->msgs_out.inflight, message);
//                 mosq->msgs_out.queue_len++;
//         }else{                  
//                 DL_APPEND(mosq->msgs_in.inflight, message);
//                 mosq->msgs_in.queue_len++;
//         }               
                
//         return message__release_to_inflight(mosq, dir);
// } 

void message__reconnect_reset(struct mosquitto *mosq)
{               
        struct mosquitto_message_all *message, *tmp;
        assert(mosq);   
        
        pthread_mutex_lock(&mosq->msgs_in.mutex);
        mosq->msgs_in.inflight_quota = mosq->msgs_in.inflight_maximum;
        mosq->msgs_in.queue_len = 0;
        DL_FOREACH_SAFE(mosq->msgs_in.inflight, message, tmp){
                mosq->msgs_in.queue_len++;
                message->timestamp = 0;
                if(message->msg.qos != 2){
                        DL_DELETE(mosq->msgs_in.inflight, message);
                        message__cleanup(&message);
                }else{
                        /* Message state can be preserved here because it should match
                        * whatever the client has got. */
                        util__decrement_receive_quota(mosq);
                }
        }       
        pthread_mutex_unlock(&mosq->msgs_in.mutex);
        
        
        pthread_mutex_lock(&mosq->msgs_out.mutex);
        mosq->msgs_out.inflight_quota = mosq->msgs_out.inflight_maximum;
        mosq->msgs_out.queue_len = 0;
        DL_FOREACH_SAFE(mosq->msgs_out.inflight, message, tmp){
                mosq->msgs_out.queue_len++;

                message->timestamp = 0;
                if(mosq->msgs_out.inflight_quota != 0){
                        util__decrement_send_quota(mosq);
                        if(message->msg.qos == 1){
                                message->state = mosq_ms_publish_qos1;
                        }else if(message->msg.qos == 2){
                                if(message->state == mosq_ms_wait_for_pubrec){
                                        message->state = mosq_ms_publish_qos2;
                                }else if(message->state == mosq_ms_wait_for_pubcomp){
                                        message->state = mosq_ms_resend_pubrel;
                                }
                                /* Should be able to preserve state. */
                        }
                }else{
                        message->state = mosq_ms_invalid;
                }
        }
        pthread_mutex_unlock(&mosq->msgs_out.mutex);
}



///////////////////////////////net_mosq.c///////////////////////////////////


ssize_t net__write(struct mosquitto *mosq, void *buf, size_t count)
{                       
// #ifdef WITH_TLS                 
//         int ret;                
//         int err;                
// #endif                  
        assert(mosq);
                                
        errno = 0;
// #ifdef WITH_TLS                 
//         if(mosq->ssl){
//                 mosq->want_write = false;       
//                 ret = SSL_write(mosq->ssl, buf, count);
//                 if(ret < 0){                    
//                         err = SSL_get_error(mosq->ssl, ret);
//                         if(err == SSL_ERROR_WANT_READ){
//                                 ret = -1;
//                                 errno = EAGAIN;
//                         }else if(err == SSL_ERROR_WANT_WRITE){
//                                 ret = -1;
//                                 mosq->want_write = true;
//                                 errno = EAGAIN; 
//                         }else{                          
//                                 net__print_ssl_error(mosq);
//                                 errno = EPROTO;         
//                         }               
//                         ERR_clear_error();
// #ifdef WIN32
//                         WSASetLastError(errno);
// #endif
//                 }
//                 return (ssize_t )ret;
//         }else{
//                 /* Call normal write/send */
// #endif

// #ifndef WIN32
//         return write(mosq->sock, buf, count);
// #else
        return send(mosq->sock, buf, count, 0);
// #endif

// #ifdef WITH_TLS
        // }
// #endif
}

int net__socket_close(struct mosquitto *mosq)  
{
        int rc = 0;

        assert(mosq);
// #ifdef WITH_TLS
// #ifdef WITH_WEBSOCKETS
//         if(!mosq->wsi)
// #endif
//         {
//                 if(mosq->ssl){
//                         if(!SSL_in_init(mosq->ssl)){
//                                 SSL_shutdown(mosq->ssl);
//                         }
//                         SSL_free(mosq->ssl);
//                         mosq->ssl = NULL;
//                 }
//         }
// #endif

// #ifdef WITH_WEBSOCKETS
//         if(mosq->wsi) 
//         {
//                 if(mosq->state != mosq_cs_disconnecting){
//                         mosquitto__set_state(mosq, mosq_cs_disconnect_ws);
//                 }
//                 libwebsocket_callback_on_writable(mosq->ws_context, mosq->wsi);
//         }else
// #endif
        {
                if(mosq->sock != INVALID_SOCKET){
#ifdef WITH_BROKER
                        // HASH_DELETE(hh_sock, db->contexts_by_sock, mosq);
#endif
                        rc = close(mosq->sock);
                        mosq->sock = INVALID_SOCKET;
                }
        }

#ifdef WITH_BROKER
        if(mosq->listener){
                mosq->listener->client_count--;
        }
#endif

        return rc;
}

int net__socketpair(mosq_sock_t *pairR, mosq_sock_t *pairW)
{
// #ifdef WIN32
// 	int family[2] = {AF_INET, AF_INET6};
// 	int i;
// 	struct sockaddr_storage ss;
// 	struct sockaddr_in *sa = (struct sockaddr_in *)&ss;
// 	struct sockaddr_in6 *sa6 = (struct sockaddr_in6 *)&ss;
// 	socklen_t ss_len;
// 	mosq_sock_t spR, spW;

// 	mosq_sock_t listensock;

// 	*pairR = INVALID_SOCKET;
// 	*pairW = INVALID_SOCKET;

// 	for(i=0; i<2; i++){
// 		memset(&ss, 0, sizeof(ss));
// 		if(family[i] == AF_INET){
// 			sa->sin_family = family[i];
// 			sa->sin_addr.s_addr = htonl(INADDR_LOOPBACK);
// 			sa->sin_port = 0;
// 			ss_len = sizeof(struct sockaddr_in);
// 		}else if(family[i] == AF_INET6){
// 			sa6->sin6_family = family[i];
// 			sa6->sin6_addr = in6addr_loopback;
// 			sa6->sin6_port = 0;
// 			ss_len = sizeof(struct sockaddr_in6);
// 		}else{
// 			return MOSQ_ERR_INVAL;
// 		}

// 		listensock = socket(family[i], SOCK_STREAM, IPPROTO_TCP);
// 		if(listensock == -1){
// 			continue;
// 		}

// 		if(bind(listensock, (struct sockaddr *)&ss, ss_len) == -1){
// 			close(listensock);
// 			continue;
// 		}

// 		if(listen(listensock, 1) == -1){
// 			close(listensock);
// 			continue;
// 		}
// 		memset(&ss, 0, sizeof(ss));
// 		ss_len = sizeof(ss);
// 		if(getsockname(listensock, (struct sockaddr *)&ss, &ss_len) < 0){
// 			close(listensock);
// 			continue;
// 		}

// 		if(family[i] == AF_INET){
// 			sa->sin_family = family[i];
// 			sa->sin_addr.s_addr = htonl(INADDR_LOOPBACK);
// 			ss_len = sizeof(struct sockaddr_in);
// 		}else if(family[i] == AF_INET6){
// 			sa6->sin6_family = family[i];
// 			sa6->sin6_addr = in6addr_loopback;
// 			ss_len = sizeof(struct sockaddr_in6);
// 		}

// 		spR = socket(family[i], SOCK_STREAM, IPPROTO_TCP);
// 		if(spR == -1){
// 			close(listensock);
// 			continue;
// 		}
// 		if(net__socket_nonblock(&spR)){
// 			close(listensock);
// 			continue;
// 		}
// 		if(connect(spR, (struct sockaddr *)&ss, ss_len) < 0){
// // #ifdef WIN32
// // 			errno = WSAGetLastError();
// // #endif
// 			if(errno != EINPROGRESS && errno != EWOULDBLOCK){
// 				close(spR);
// 				close(listensock);
// 				continue;
// 			}
// 		}
// 		spW = accept(listensock, NULL, 0);
// 		if(spW == -1){
// // #ifdef WIN32
// // 			errno = WSAGetLastError();
// // #endif
// 			if(errno != EINPROGRESS && errno != EWOULDBLOCK){
// 				close(spR);
// 				close(listensock);
// 				continue;
// 			}
// 		}

// 		if(net__socket_nonblock(&spW)){
// 			close(spR);
// 			close(listensock);
// 			continue;
// 		}
// 		close(listensock);

// 		*pairR = spR;
// 		*pairW = spW;
// 		return MOSQ_ERR_SUCCESS;
// 	}
// 	return MOSQ_ERR_UNKNOWN;
// #else
	int sv[2];

	if(socketpair(AF_UNIX, SOCK_STREAM, 0, sv) == -1){
		return MOSQ_ERR_ERRNO;
	}
	if(net__socket_nonblock(&sv[0])){
		close(sv[1]);
		return MOSQ_ERR_ERRNO;
	}
	if(net__socket_nonblock(&sv[1])){
		close(sv[0]);
		return MOSQ_ERR_ERRNO;
	}
	*pairR = sv[0];
	*pairW = sv[1];
	return MOSQ_ERR_SUCCESS;
// #endif
}

int net__socket_nonblock(mosq_sock_t *sock)
{
// #ifndef WIN32
        int opt;
        /* Set non-blocking */
        opt = fcntl(*sock, F_GETFL, 0);
        if(opt == -1){
                close(*sock);
                *sock = INVALID_SOCKET;
                return MOSQ_ERR_ERRNO;
        }
        if(fcntl(*sock, F_SETFL, opt | O_NONBLOCK) == -1){
                /* If either fcntl fails, don't want to allow this client to connect. */
                close(*sock);
                *sock = INVALID_SOCKET;
                return MOSQ_ERR_ERRNO;
        }
// #else
        // unsigned long opt = 1;
        // if(ioctlsocket(*sock, FIONBIO, &opt)){
        //         close(*sock);
        //         *sock = INVALID_SOCKET;
        //         return MOSQ_ERR_ERRNO;
        // }
// #endif
        return MOSQ_ERR_SUCCESS;
}

/* Create a socket and connect it to 'ip' on port 'port'.  */
int net__socket_connect(struct mosquitto *mosq, const char *host, uint16_t port, const char *bind_address, bool blocking)
{
        mosq_sock_t sock = INVALID_SOCKET;
        int rc, rc2;
                
        if(!mosq || !host || !port) return MOSQ_ERR_INVAL;

        rc = net__try_connect(host, port, &sock, bind_address, blocking);
        if(rc > 0) return rc;
         
        mosq->sock = sock;
         
#if defined(WITH_SOCKS) && !defined(WITH_BROKER)
        if(!mosq->socks5_host)
#endif       
        {
                rc2 = net__socket_connect_step3(mosq, host);
                if(rc2) return rc2;
        }

        return MOSQ_ERR_SUCCESS;
}   

int net__try_connect(const char *host, uint16_t port, mosq_sock_t *sock, const char *bind_address, bool blocking)
{
	struct addrinfo hints;
	struct addrinfo *ainfo, *rp;
	struct addrinfo *ainfo_bind, *rp_bind;
	int s;
	int rc = MOSQ_ERR_SUCCESS;
#ifdef WIN32
	uint32_t val = 1;
#endif

	*sock = INVALID_SOCKET;
	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;

	s = getaddrinfo(host, NULL, &hints, &ainfo);
	if(s){
		errno = s;
		return MOSQ_ERR_EAI;
	}

	if(bind_address){
		s = getaddrinfo(bind_address, NULL, &hints, &ainfo_bind);
		if(s){
			freeaddrinfo(ainfo);
			errno = s;
			return MOSQ_ERR_EAI;
		}
	}

	for(rp = ainfo; rp != NULL; rp = rp->ai_next){
		*sock = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
		if(*sock == INVALID_SOCKET) continue;

		if(rp->ai_family == AF_INET){
			((struct sockaddr_in *)rp->ai_addr)->sin_port = htons(port);
		}else if(rp->ai_family == AF_INET6){
			((struct sockaddr_in6 *)rp->ai_addr)->sin6_port = htons(port);
		}else{
			close(*sock);
			*sock = INVALID_SOCKET;
			continue;
		}

		if(bind_address){
			for(rp_bind = ainfo_bind; rp_bind != NULL; rp_bind = rp_bind->ai_next){
				if(bind(*sock, rp_bind->ai_addr, rp_bind->ai_addrlen) == 0){
					break;
				}
			}
			if(!rp_bind){
				close(*sock);
				*sock = INVALID_SOCKET;
				continue;
			}
		}

		if(!blocking){
			/* Set non-blocking */
			if(net__socket_nonblock(sock)){
				continue;
			}
		}

		rc = connect(*sock, rp->ai_addr, rp->ai_addrlen);
#ifdef WIN32
		errno = WSAGetLastError();
#endif
		if(rc == 0 || errno == EINPROGRESS || errno == EWOULDBLOCK){
			if(rc < 0 && (errno == EINPROGRESS || errno == EWOULDBLOCK)){
				rc = MOSQ_ERR_CONN_PENDING;
			}

			if(blocking){
				/* Set non-blocking */
				if(net__socket_nonblock(sock)){
					continue;
				}
			}
			break;
		}

		close(*sock);
		*sock = INVALID_SOCKET;
	}
	freeaddrinfo(ainfo);
	if(bind_address){
		freeaddrinfo(ainfo_bind);
	}
	if(!rp){
		return MOSQ_ERR_ERRNO;
	}
	return rc;
}

int net__socket_connect_step3(struct mosquitto *mosq, const char *host)
{       
// #ifdef WITH_TLS 
//         BIO *bio;

//         int rc = net__init_ssl_ctx(mosq);
//         if(rc) return rc;

//         if(mosq->ssl_ctx){
//                 if(mosq->ssl){
//                         SSL_free(mosq->ssl);
//                 }
//                 mosq->ssl = SSL_new(mosq->ssl_ctx);
//                 if(!mosq->ssl){
//                         COMPAT_CLOSE(mosq->sock);
//                         mosq->sock = INVALID_SOCKET;
//                         net__print_ssl_error(mosq);
//                         return MOSQ_ERR_TLS;
//                 }

//                 SSL_set_ex_data(mosq->ssl, tls_ex_index_mosq, mosq);
//                 bio = BIO_new_socket(mosq->sock, BIO_NOCLOSE);
//                 if(!bio){
//                         COMPAT_CLOSE(mosq->sock);
//                         mosq->sock = INVALID_SOCKET;
//                         net__print_ssl_error(mosq);
//                         return MOSQ_ERR_TLS;
//                 }
//                 SSL_set_bio(mosq->ssl, bio, bio);

//                 /*
//                  * required for the SNI resolving
//                  */
//                 if(SSL_set_tlsext_host_name(mosq->ssl, host) != 1) {
//                         COMPAT_CLOSE(mosq->sock);
//                         mosq->sock = INVALID_SOCKET;
//                         return MOSQ_ERR_TLS;
//                 }

//                 if(net__socket_connect_tls(mosq)){
//                         return MOSQ_ERR_TLS;
//                 }

//         }
// #endif
        return MOSQ_ERR_SUCCESS;
}


///////////////////////////////send_connect.c///////////////////////////////////


int send__connect(struct mosquitto *mosq, uint16_t keepalive, bool clean_session, const mosquitto_property *properties)
{
	struct mosquitto__packet *packet = NULL;
	int payloadlen;
	uint8_t will = 0;
	uint8_t byte;
	int rc;
	uint8_t version;
	char *clientid, *username, *password;
	int headerlen;
	int proplen = 0, will_proplen, varbytes;
	mosquitto_property *local_props = NULL;
	uint16_t receive_maximum;

	assert(mosq);

	if(mosq->protocol == mosq_p_mqtt31 && !mosq->id) return MOSQ_ERR_PROTOCOL;

#if defined(WITH_BROKER) && defined(WITH_BRIDGE)
	if(mosq->bridge){
		clientid = mosq->bridge->remote_clientid;
		username = mosq->bridge->remote_username;
		password = mosq->bridge->remote_password;
	}else{
		clientid = mosq->id;
		username = mosq->username;
		password = mosq->password;
	}
#else
	clientid = mosq->id;
	username = mosq->username;
	password = mosq->password;
#endif

	if(mosq->protocol == mosq_p_mqtt5){
		/* Generate properties from options */
		if(!mosquitto_property_read_int16(properties, MQTT_PROP_RECEIVE_MAXIMUM, &receive_maximum, false)){
			rc = mosquitto_property_add_int16(&local_props, MQTT_PROP_RECEIVE_MAXIMUM, mosq->msgs_in.inflight_maximum);
			if(rc) return rc;
		}else{
			mosq->msgs_in.inflight_maximum = receive_maximum;
			mosq->msgs_in.inflight_quota = receive_maximum;
		}

		version = MQTT_PROTOCOL_V5;
		headerlen = 10;
		proplen = 0;
		proplen += property__get_length_all(properties);
		proplen += property__get_length_all(local_props);
		varbytes = packet__varint_bytes(proplen);
		headerlen += proplen + varbytes;
	}else if(mosq->protocol == mosq_p_mqtt311){
		version = MQTT_PROTOCOL_V311;
		headerlen = 10;
	}else if(mosq->protocol == mosq_p_mqtt31){
		version = MQTT_PROTOCOL_V31;
		headerlen = 12;
	}else{
		return MOSQ_ERR_INVAL;
	}

	packet = (mosquitto__packet*)calloc(1, sizeof(struct mosquitto__packet));
	if(!packet) return MOSQ_ERR_NOMEM;

	if(clientid){
		payloadlen = 2+strlen(clientid);
	}else{
		payloadlen = 2;
	}
	if(mosq->will){
		will = 1;
		assert(mosq->will->msg.topic);

		payloadlen += 2+strlen(mosq->will->msg.topic) + 2+mosq->will->msg.payloadlen;
		if(mosq->protocol == mosq_p_mqtt5){
			will_proplen = property__get_length_all(mosq->will->properties);
			varbytes = packet__varint_bytes(will_proplen);
			payloadlen += will_proplen + varbytes;
		}
	}

	/* After this check we can be sure that the username and password are
	 * always valid for the current protocol, so there is no need to check
	 * username before checking password. */
	if(mosq->protocol == mosq_p_mqtt31 || mosq->protocol == mosq_p_mqtt311){
		if(password != NULL && username == NULL){
			return MOSQ_ERR_INVAL;
		}
	}

	if(username){
		payloadlen += 2+strlen(username);
	}
	if(password){
		payloadlen += 2+strlen(password);
	}

	packet->command = CMD_CONNECT;
	packet->remaining_length = headerlen + payloadlen;
	rc = packet__alloc(packet);
	if(rc){
		free(packet);
		return rc;
	}

	/* Variable header */
	if(version == MQTT_PROTOCOL_V31){
		packet__write_string(packet, PROTOCOL_NAME_v31, strlen(PROTOCOL_NAME_v31));
	}else{
		packet__write_string(packet, PROTOCOL_NAME, strlen(PROTOCOL_NAME));
	}
#if defined(WITH_BROKER) && defined(WITH_BRIDGE)
	if(mosq->bridge && mosq->bridge->try_private && mosq->bridge->try_private_accepted){
		version |= 0x80;
	}else{
	}
#endif
	packet__write_byte(packet, version);
	byte = (clean_session&0x1)<<1;
	if(will){
		byte = byte | ((mosq->will->msg.retain&0x1)<<5) | ((mosq->will->msg.qos&0x3)<<3) | ((will&0x1)<<2);
	}
	if(username){
		byte = byte | 0x1<<7;
	}
	if(mosq->password){
		byte = byte | 0x1<<6;
	}
	packet__write_byte(packet, byte);
	packet__write_uint16(packet, keepalive);

	if(mosq->protocol == mosq_p_mqtt5){
		/* Write properties */
		packet__write_varint(packet, proplen);
		property__write_all(packet, properties, false);
		property__write_all(packet, local_props, false);
	}
	mosquitto_property_free_all(&local_props);

	/* Payload */
	if(clientid){
		packet__write_string(packet, clientid, strlen(clientid));
	}else{
		packet__write_uint16(packet, 0);
	}
	if(will){
		if(mosq->protocol == mosq_p_mqtt5){
			/* Write will properties */
			property__write_all(packet, mosq->will->properties, true);
		}
		packet__write_string(packet, mosq->will->msg.topic, strlen(mosq->will->msg.topic));
		packet__write_string(packet, (const char *)mosq->will->msg.payload, mosq->will->msg.payloadlen);
	}

	if(username){
		packet__write_string(packet, username, strlen(username));
	}
	if(password){
		packet__write_string(packet, password, strlen(password));
	}

	mosq->keepalive = keepalive;
#ifdef WITH_BROKER
# ifdef WITH_BRIDGE
	log__printf(mosq, MOSQ_LOG_DEBUG, "Bridge %s sending CONNECT", clientid);
# endif
#else
	log__printf(mosq, MOSQ_LOG_DEBUG, "Client %s sending CONNECT", clientid);
#endif
	return packet__queue(mosq, packet);
}
